from django.shortcuts import render
from django.http import HttpResponseRedirect
from .models import TodoItem


def todoview(request):
    total_objects = TodoItem.objects.all()
    return render(request, 'todo.html',
                  {'total_elements': total_objects})


def addtodo(request):
    new_item = TodoItem(content=request.POST['content'])
    new_item.save()
    return HttpResponseRedirect('/todo/')


def deletetodo(request, todo_id):
    item_to_delete = TodoItem.objects.get(id=todo_id)
    item_to_delete.delete()
    return HttpResponseRedirect('/todo/')



